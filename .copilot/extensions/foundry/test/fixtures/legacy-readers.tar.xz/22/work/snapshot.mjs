import { planDirectory, validOutcome } from "./contract.mjs";
import { checkReceipt, goalReceipt } from "./evidence.mjs";
import { validFeedback } from "./feedback.mjs";
import { attachedNotes, noteId, noteText, sourceReceipt } from "./notes.mjs";
import { indexBudgetError, validMatch } from "./pages.mjs";
import { assignmentCount, unissued } from "./native.mjs";
import { checked, owns, validateNodes } from "./plan.mjs";
import { outside } from "./product.mjs";
import { investigation } from "./reviews.mjs";
import { fail, relative } from "./values.mjs";

/** @typedef {(value:unknown)=>boolean} Guard */
/** @type {Guard} */
const string = value => typeof value === "string";
/** @type {Guard} */
const id = value => typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(value) && !Object.hasOwn(Object.prototype, value);
/** @type {Guard} */
const commit = value => typeof value === "string" && /^(?:[0-9a-f]{40}|[0-9a-f]{64})$/.test(value);
/** @type {Guard} */
const path = value => typeof value === "string" && relative(value) === value;
/** @type {Guard} */
const count = value => typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
/** @type {Guard} */
const positive = v => count(v) && v !== 0;
/** @type {Guard} */
const bool = value => typeof value === "boolean";
/** @param {unknown} v @returns {v is Record<string,unknown>} */
const object = v => typeof v === "object" && v !== null && !Array.isArray(v);
/** @param {...string} states @returns {Guard} */
const one = (...states) => v => typeof v === "string" && states.includes(v);
/** @param {Guard} guard @returns {Guard} */
const optional = guard => v => v === undefined || guard(v);
/** @param {Guard} guard @returns {Guard} */
const list = guard => v => Array.isArray(v) && v.every(guard);
/** @param {Guard} guard @returns {Guard} */
const named = guard => v => object(v) && Object.entries(v).every(([k, item]) => id(k) && guard(item));
/** @param {Record<string,Guard>} fields @returns {Guard} */
const shape = fields => v => object(v) && Object.entries(fields).every(([key, guard]) => guard(v[key]));
const output = { id, directory: path, revision: optional(commit), check: path, needs: list(id) };
const grain = shape({ ...output, specification: path, boundary: list(path), task: optional(string), agent: optional(string) });
const proposal = shape({ ...output, task: string });
const charter = { id, charter: path, agent: optional(string) };
const fixed = shape({ ...charter, grains: list(id) });
const area = shape({ ...charter, areas: list(path), boundary: list(path), checks: list(path), researchAgent: optional(id) });
const policy = shape({
	id, direction: string, target: string, source: path, sharedBrief: optional(path), base: commit, productCheck: path, goalCheck: optional(path), files: list(path),
	squads: list(s => object(s) && ("areas" in s ? !("grains" in s) && area(s) : fixed(s))),
	workers: optional(positive), assignments: optional(count), repairs: count, deadline: optional(string), seed: optional(list(id))
});
/** @type {Guard} */
const observation = v => object(v) && string(v.reason) && Array.isArray(v.evidence) && v.evidence.length > 0 && v.evidence.every(path) &&
	Array.isArray(v.grains) && v.grains.every(g => id(g) || proposal(g)) && validOutcome(v.outcome, v.grains.length) &&
	(v.ownerInput === undefined || v.outcome === "needs-decision" && one("product-choice", "external-action")(v.ownerInput)) &&
	(v.references === undefined || Array.isArray(v.findings) && list(shape({ repo: id, revision: commit }))(v.references)) &&
	(v.findings === undefined ? v.outcome !== "researched" : (v.outcome === "researched" || v.outcome === "needs-decision" || v.outcome === "unresolved" || v.outcome === "waiting") &&
		list(shape({ kind: string, source: string, finding: string }))(v.findings) && (v.outcome !== "researched" || Array.isArray(v.findings) && v.findings.length > 0)) &&
	(v.outcome === "waiting" ? id(v.waitFor) || typeof v.waitFor === "string" && v.waitFor.startsWith("reference:") && id(v.waitFor.slice(10)) : v.waitFor === undefined) &&
	[v.file, v.receipt, v.detail].filter(k => k !== undefined).length === Number(v.outcome === "needs-evidence") &&
	optional(path)(v.file) && optional(id)(v.receipt) && optional(id)(v.detail) &&
	(v.offset === undefined || v.outcome === "needs-evidence" && count(v.offset)) &&
	(v.match === undefined || v.outcome === "needs-evidence" && validMatch(v.match)) &&
	(v.replace === undefined || v.outcome === "regenerate" && list(id)(v.replace));
/** @param {unknown} v @returns {v is import("./model.js").Packet} */
export const isPacket = v => object(v) && id(v.review) && commit(v.base) && bool(v.partial) && object(v.files) &&
	(v.sources === undefined || Array.isArray(v.sources) && v.sources.every(s => typeof s === "string" &&
		(s.startsWith("receipt:") && id(s.slice(8)) || s.startsWith("detail:") && commit(s.slice(7))))) &&
	(v.read === undefined || v.partial === true && object(v.read) && typeof v.read.source === "string" &&
		[v.read.start, v.read.end, v.read.length].every(count) && Number(v.read.end) <= Number(v.read.length) &&
		(v.read.hit === undefined || count(v.read.hit) && Number(v.read.start) <= Number(v.read.hit) && Number(v.read.hit) < Number(v.read.end)) &&
		(v.read.miss === true ? v.read.start === v.read.end && v.read.hit === undefined : v.read.miss === undefined && Number(v.read.start) < Number(v.read.end)) &&
		(v.read.source.startsWith("file:") ? path(v.read.source.slice(5)) && (v.read.miss === true || object(v.excerpt) &&
			v.read.source.slice(5) === v.excerpt.path && v.excerpt.start === v.read.start && v.excerpt.end === v.read.end && v.excerpt.length === v.read.length) :
			Array.isArray(v.sources) && v.sources.includes(v.read.source))) &&
	(v.excerpt === undefined || v.partial === true && object(v.excerpt) && path(v.excerpt.path) && commit(v.excerpt.oid) &&
		[v.excerpt.start, v.excerpt.end, v.excerpt.length].every(count) && Number(v.excerpt.start) < Number(v.excerpt.end) &&
		Number(v.excerpt.end) <= Number(v.excerpt.length) && !Object.hasOwn(v.files, String(v.excerpt.path))) &&
	Object.entries(v.files).every(([p, oid]) => path(p) && commit(oid)) && named(commit)(v.outputs);
/** @type {Guard} */
const decision = v => object(v) && (v.status === "presenting" && optional(id)(v.presentation) || v.status === "dismissed" ||
	v.status === "answered" && string(v.answer) ||
	v.status === "unavailable" && string(v.reason) && optional(id)(v.presentation));
const node = shape({
	grain, review: optional(id), state: one("idle", "waiting", "writing", "checking", "published", "qualified", "repeated", "blocked"), token: optional(id), worker: optional(string),
	generation: optional(commit), inputs: optional(named(commit)), base: optional(commit), replaces: optional(commit), candidate: optional(commit), check: optional(id),
	priorSource: optional(shape({ directory: path, revision: commit, tree: commit })),
	repairs: count, reason: optional(string), artifactCursor: optional(count)
});
const assessment = { target: commit, commit, check: id };
const product = shape({ ...assessment, outputs: named(commit), qualifiedAt: optional(positive) });
const receipt = shape({ commit, check: path, evaluatorRevision: optional(commit), exit: v => v === null || count(v), output: string,
	failure: optional(one("changed-export", "incomplete")), repair: optional(id), squad: optional(id), feedback: optional(validFeedback),
	feedbackFile: optional(shape({ blob: commit, legacy: optional(bool) })) });
const dispatch = { id, issuer: string, args: object, evaluatorRevision: optional(commit), callId: optional(string), error: optional(string), permissionHold: optional(string) };
const noteFields = { receipt: id, question: noteText, excerpt: optional(noteText) };
const scout = shape({ ...dispatch, kind: one("scout"), tool: one("workflow"), squad: id, base: commit, version: string,
	state: one("ready", "issued", "uncertain", "suspended", "reported", "observed", "blocked", "deferred"), observation: optional(observation),
	deferred: optional(shape({ pins: v => named(commit)(v) && object(v) && Object.keys(v).length > 0,
		consumers: v => Array.isArray(v) && v.length > 0 && v.every(id) && new Set(v).size === v.length })),
	workflowId: optional(string), decision: optional(decision), packet: optional(isPacket), retryOf: optional(id), note: optional(shape(noteFields)), predecessor: optional(node),
	otherNotes: optional(list(shape(noteFields))), diagnostic: optional(shape({ receipt: id, excerpt: noteText })), wake: optional(shape({ review: id, key: string })) });
const native = shape({
	...dispatch, kind: one("writer", "component", "product", "goal", "repair", "decision", "handoff", "artifact"), grain: optional(id), inlineRepair: optional(id),
	usedArtifacts: optional(list(commit)), comparedArtifacts: optional(list(commit)),
	baseline: optional(shape({ directory: path, revision: commit, tree: commit })),
	readGrant: optional(shape({ directory: path, revision: commit, tree: commit })),
	claims: optional(list(shape({ actor: string, path: string, start: string, kickoff: string, identity: string }))), claimedRequest: optional(string),
	token: optional(id), tool: one("create_session", "bash", "send_session_message", "session.send"), state: one("ready", "issued", "uncertain", "ordinary", "done", "refused"),
	nativeId: optional(string), boundAt: optional(positive), commit: optional(commit), check: optional(path),
	runnerStarted: optional(bool), receipt: optional(receipt)
});
const snapshot = shape({
	id, owner: string, policy, references: optional(named(commit)),
	repins: optional(list(shape({ from: commit, revision: commit, files: list(path) }))),
	artifacts: optional(list(shape({ file: path, blob: commit, base: commit, publisher: string, to: list(path) }))),
	pendingReviewNotes: optional(list(shape({ ...noteFields, squad: id, after: count }))),
	active: bool, activatedAt: positive, pauseReason: optional(string), nodes: named(node), effects: list(v => scout(v) || native(v)),
	products: list(product), join: optional(product), goal: optional(shape({ ...assessment, stall: optional(string),
		tried: optional(list(v => typeof v === "string" && /^[0-9a-f]{64}$/.test(v))) })),
	blocker: optional(string), conflict: optional(string), discoveryError: optional(string)
});

/** @param {unknown} value @returns {value is import("./model.js").Run} */
function isRun(value) { return snapshot(value); }

/** @param {import("./model.js").Run} run @param {import("./model.js").Effect} e */
function validDispatch(run, e) {
	if (e.permissionHold !== undefined && !unissued(e)) return false;
	if (e.receipt?.feedback !== undefined && e.receipt.feedbackFile) return false;
	if ((e.receipt?.feedback !== undefined || e.receipt?.feedbackFile) && (e.kind !== "goal" || !e.runnerStarted || !e.callId ||
		e.receipt.exit !== 0 && e.receipt.exit !== 1)) return false;
	if (e.evaluatorRevision && (!(e.kind === "goal" || e.kind === "scout") || !run.repins?.some(p => p.revision === e.evaluatorRevision))) return false;
	if (e.receipt?.failure && (e.kind !== "component" || !e.runnerStarted || !e.callId || e.receipt.exit !== null ||
		e.receipt.repair || e.receipt.squad || e.state !== "done" && e.state !== "refused")) return false;
	if (e.tool === "workflow") {
		const squad = run.policy.squads.find(s => s.id === e.squad), report = e.observation;
		if (e.diagnostic) {
			const d = e.diagnostic, src = run.effects.find(r => r.id === e.retryOf), receipt = sourceReceipt(run.effects.find(r => r.id === d.receipt), d);
			if (src?.kind !== "scout" || src.error !== indexBudgetError || src.packet || src.note ||
				receipt?.exit !== 1 || receipt.commit !== e.base || receipt.evaluatorRevision !== e.evaluatorRevision || e.packet && !e.packet.partial) return false;
		}
		if (e.predecessor) {
			const n = e.predecessor, g = report?.grains[0];
			if (e.state !== "observed" || report?.outcome !== "regenerate" || report.grains.length !== 1 || typeof g !== "object" ||
				n.state !== "blocked" || !n.reason?.startsWith("Writer reports missing input: ") || !n.worker || !n.base || n.base === e.base ||
				g.id === n.grain.id || g.directory !== n.grain.directory || g.check !== n.grain.check ||
				!run.effects.some(w => w.kind === "writer" && w.grain === n.grain.id && w.nativeId === n.worker && w.state === "done")) return false;
		}
		if (e.retryOf && (e.issuer !== run.owner || !run.effects.some(src => src.kind === "scout" && src.id === e.retryOf &&
			!src.retryOf && src.state === "blocked" && !src.observation && src.workflowId && src.squad === e.squad && src.base === e.base &&
			src.version === e.version && src.evaluatorRevision === e.evaluatorRevision) ||
			run.effects.some(other => other !== e && other.kind === "scout" && other.retryOf === e.retryOf))) return false;
		return !!squad && !e.nativeId && !e.token && !e.receipt && !e.boundAt && (!e.workflowId || !!e.callId) &&
			(e.state !== "suspended" || !!e.workflowId) &&
			(e.wake?.key !== "research" && report?.outcome !== "needs-research" || "areas" in squad && !!squad.researchAgent) &&
			(!report || investigation(e, squad) === (report.findings !== undefined)) &&
			(!e.packet || e.packet.review === e.id && e.packet.base === e.base) &&
			(e.state !== "reported" && e.state !== "observed" && e.state !== "deferred" || !!report && !!e.workflowId && !!e.packet) &&
			(e.state === "deferred" ? !!e.deferred && "areas" in squad && report?.outcome === "regenerate" : !e.deferred) &&
			(e.wake?.key !== "released-inputs" || run.effects.some(src => src.kind === "scout" && src.state === "deferred" &&
				src.squad === e.squad && src.id === e.wake?.review)) &&
			(!e.decision || e.state === "observed" && report?.outcome === "needs-decision") &&
			("areas" in squad || !report || !report.replace && report.grains.every(g => typeof g === "string"));
	}
	if (e.workflowId || Boolean(e.nativeId) !== Boolean(e.boundAt)) return false;
	if (e.readGrant && (e.kind !== "writer" || e.state !== "done" || !e.callId)) return false;
	if (e.baseline && (e.kind !== "repair" || e.issuer !== run.owner || e.tool !== "send_session_message" ||
		!run.effects.some(w => w.kind === "writer" && w.state === "done" && w.grain === e.grain && w.nativeId === e.args.session_id))) return false;
	if (e.claims && (e.kind !== "writer" || !e.callId || !e.claims.length ||
		new Set(e.claims.map(c => c.actor)).size !== e.claims.length)) return false;
	if (e.claimedRequest && (e.state !== "done" || e.claims?.length !== 1 || e.claims[0].actor !== e.nativeId)) return false;
	if (e.inlineRepair && (e.kind !== "component" || !checkReceipt(e))) return false;
	if ((e.usedArtifacts || e.comparedArtifacts) && e.kind !== "component") return false;
	if (e.kind === "writer") return e.tool === "create_session" && !!e.grain && !!e.token && (e.state === "done") === !!e.nativeId;
	if (e.nativeId) return false;
	if (e.kind === "goal" || e.kind === "product" || e.kind === "component")
		return e.tool === "bash" && !!e.commit && !!e.check && (e.kind === "component") === !!e.grain &&
			(!e.receipt || e.receipt.commit === e.commit && e.receipt.check === e.check && e.receipt.evaluatorRevision === e.evaluatorRevision) &&
			(!e.receipt?.squad || e.kind === "goal" && e.receipt.exit === 1 && run.policy.squads.some(s => s.id === e.receipt?.squad));
	if (!e.token || e.receipt || !string(e.args.message)) return false;
	if (e.kind === "repair" || e.kind === "artifact") return !!e.grain && (e.tool === "send_session_message" || e.tool === "session.send" && e.state !== "ordinary");
	return e.issuer === run.owner ? e.kind === "handoff" && e.tool === "session.send" && e.state !== "ordinary"
		: e.tool === "send_session_message" && e.args.session_id === run.owner;
}

/** @param {unknown} value @returns {import("./model.js").Run} */
export function decode(value) {
	if (!isRun(value) || value.policy.id !== value.id || value.active && value.pauseReason !== undefined ||
		"capacity" in value || value.policy.assignments !== undefined && assignmentCount(value) > value.policy.assignments ||
		Boolean(value.policy.goalCheck) !== Boolean(value.goal) || value.goal && value.policy.seed)
		fail("corrupt_run", "Invalid Foundry execution snapshot");
	const { policy: p, nodes, products } = value, areas = p.squads.filter(s => "areas" in s), files = new Set(p.files);
	const effects = new Map(value.effects.map(e => [e.id, e]));
	const grants = new Map(value.effects.flatMap(e => e.kind === "writer" && e.readGrant ? [[e.token, e]] : []));
	const queued = value.pendingReviewNotes ?? [];
	if (new Set(queued.map(n => `${n.squad}:${noteId(n)}`)).size !== queued.length || queued.some(n => n.after > value.effects.length ||
		!p.squads.some(s => s.id === n.squad) || !sourceReceipt(effects.get(n.receipt), n)) ||
		value.effects.some(e => e.kind === "scout" && (e.otherNotes && !e.note || e.note && (!e.workflowId || e.retryOf ||
			p.squads.some(s => s.id === e.squad && investigation(e, s)) || attachedNotes(e).some(n => !sourceReceipt(effects.get(n.receipt), n))))))
		fail("corrupt_run", "Invalid historical receipt for scout review");
	const pins = value.repins ?? [];
	if (pins.length && (!value.goal || new Set([p.base, ...pins.map(pin => pin.revision)]).size !== pins.length + 1 ||
		pins.some((pin, i) => pin.from !== (i ? pins[i-1].revision : p.base) || !pin.files.length ||
			new Set(pin.files).size !== pin.files.length || !pin.files.every(f => f.startsWith(".foundry/")))))
		fail("corrupt_run", "Invalid goal evaluator pin history");
	const last = products.at(-1);
	if (effects.size !== value.effects.length || value.effects.some(e => !validDispatch(value, e)))
		fail("corrupt_run", "Invalid Foundry dispatch");
	if (areas.length && (!value.goal || areas.length !== value.policy.squads.length) ||
		p.sharedBrief !== undefined && (!areas.length || p.sharedBrief !== `${planDirectory(p.source)}/journey.md` ||
			areas.some(s => s.boundary.length !== 1 || s.boundary[0] !== p.sharedBrief)) ||
		![p.source, p.productCheck, ...(p.goalCheck ? [p.goalCheck] : []), ...p.squads.flatMap(s => "areas" in s ? [s.charter, ...s.boundary, ...s.checks] : [s.charter])].every(f => files.has(f)) ||
		[p.seed ?? [], ...p.squads.flatMap(s => "grains" in s ? [s.grains] : [])].some(ids => ids.some(id => !Object.hasOwn(nodes, id))) ||
		Object.entries(nodes).some(([id, n]) => {
			const g = n.grain, e = n.check ? effects.get(n.check) : undefined;
			if (n.priorSource && (!n.base || n.priorSource.directory !== g.directory || n.priorSource.revision !== (g.revision ?? n.base))) return true;
			const w = grants.get(n.token);
			if (w?.readGrant && (w.grain !== id || w.nativeId !== n.worker || w.readGrant.directory !== g.directory ||
				w.readGrant.revision !== n.priorSource?.revision || w.readGrant.tree !== n.priorSource.tree)) return true;
			if (id !== g.id || ![g.specification, g.check, ...g.boundary].every(f => files.has(f)) || !outside(g.directory, p.files)) return true;
			if ((n.state === "checking" || checked(n)) && (e?.kind !== "component" || e.grain !== id || e.commit !== n.candidate || e.check !== g.check)) return true;
			if (checked(n) && checkReceipt(e)?.exit !== 0) return true;
			if (n.state === "qualified" && last?.outputs[id] !== n.candidate) return true;
			return areas.length ? n.state === "idle" || !g.task || !areas.some(s => owns(s, g.directory) && s.checks.includes(g.check) &&
				g.specification === s.charter && g.agent === s.agent && g.boundary.length === s.boundary.length && g.boundary.every((b, i) => b === s.boundary[i])) : g.task !== undefined;
		}))
		fail("corrupt_run", "Invalid Foundry task graph");
	validateNodes(nodes);
	for (const product of value.join ? [...products, value.join] : products) {
		const e = effects.get(product.check);
		if (e?.kind !== "product" || e.commit !== product.commit || e.check !== p.productCheck)
			fail("corrupt_run", "Product does not match its exact check reservation");
		if (product === value.join ? product.qualifiedAt !== undefined :
			checkReceipt(e)?.exit !== 0 || (!value.goal && !product.qualifiedAt || value.goal && product.qualifiedAt && last !== product))
			fail("corrupt_run", "Checkpoint requires an exact passing product receipt");
	}
	if (last?.qualifiedAt && value.goal && (value.active || last.commit !== value.goal.commit ||
		last.target !== value.goal.target || goalReceipt(value)?.exit !== 0))
		fail("corrupt_run", "Goal acceptance requires both exact runner receipts");
	return value;
}
