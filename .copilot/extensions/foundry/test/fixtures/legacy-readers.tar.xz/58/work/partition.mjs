import { outside } from "./product.mjs";
import { checkReceipt } from "./evidence.mjs";
import { touchesCut } from "./transfer.mjs";
import { contains, covers, digest, mixed, roots, sameScope, scopeLabel } from "./values.mjs";

/** @param {import("./model.js").Run} run @param {string} from @param {string} historical */
export function historicalGrant(run,from,historical) {
	const product=run.products.find(p=>p.check===historical), candidate=product?.outputs[from];
	if (!product || !candidate) return;
	const index=run.effects.findIndex(e=>e.id===historical), prior=run.effects.slice(0,index);
	const component=prior.findLast(e=>e.kind==="component" && e.grain===from && e.commit===candidate && checkReceipt(e)?.exit===0);
	const launch=component && prior.slice(0,prior.indexOf(component)).findLast(e=>e.kind==="writer" && e.grain===from && e.nativeId===component.issuer && e.state==="done");
	if (!launch || !component?.commit) return;
	const review=prior.slice(0,prior.indexOf(launch)).findLast(e=>e.kind==="scout" && e.state==="observed" &&
		e.observation?.outcome==="regenerate" && e.observation.grains.some(g=>typeof g!=="string" && g.id===from));
	const g=review?.kind==="scout" && review.observation?.grains.find(g=>typeof g!=="string" && g.id===from);
	if (review?.kind==="scout" && g && typeof g!=="string" && mixed(g.directory) && component.check===g.check &&
		launch.kind==="writer" && (!launch.finished || sameScope(launch.finished.directory,g.directory)))
		return {product,component,candidate:component.commit,scope:g.directory,grain:g,squad:review.squad};
}

/** @param {import("./model.js").Run} run @param {import("./model.js").Node} n */
export function validRestoration(run,n) {
	const r=n.restoration;
	if (!r) return false;
	const h=historicalGrant(run,r.from,r.historical), p=run.products.find(p=>p.check===r.checkpoint), owner=run.nodes[r.retainer];
	const goal=run.effects.find(e=>e.id===r.goal);
	return h && p && run.products.indexOf(h.product)<=run.products.indexOf(p) && owner && !run.nodes[r.from] &&
		goal?.kind==="goal" && goal.commit===p.commit && [1,2].includes(checkReceipt(goal)?.exit ?? -1) &&
		n.grain.directory===h.scope.primary && n.grain.check===h.component.check && !n.grain.revision && !n.review && !n.reuse &&
		digest(n.grain.needs)===digest(h.grain.needs) && h.scope.files.every(f=>covers(owner.grain.directory,f) && !touchesCut(owner.retained ?? [],f)) &&
		n.base===p.commit && !Array.isArray(n.priorSource) && n.priorSource?.tree===r.tree &&
		outside(owner.grain.directory,[h.scope.primary]);
}

/** @param {import("./model.js").Run} run @param {import("./model.js").Pairing} pair @param {string} [target] */
export function matchesPair(run,pair,target) {
	const owner=run.nodes[pair.retainer], p=run.products.at(-1);
	return !!p && p.target===pair.target && (target===undefined || target===pair.target) &&
		p.check===pair.checkpoint && run.goal?.check===pair.goal && owner?.state==="published" &&
		owner.candidate===pair.candidate && owner.check===pair.component;
}

/** @param {import("./model.js").Run} run @param {import("./model.js").NativeCall} e */
export function pairedInput(run,e) {
	const old=e.observer && run.effects.find(x=>x.id===e.observer?.pair);
	return e.pair ?? (old?.kind==="component" ? old.pair : undefined);
}

/** The prior grant is superseded only by a later passing product which included the fresh
 * writer's own check and froze both new owners. A component alone cannot release the hold.
 * @param {import("./model.js").Run} run @param {import("./model.js").NativeCall} writer */
export function restoredProduct(run,writer) {
	const r=writer.restoration,to=writer.grain;
	if (!r || !to || !writer.nativeId || writer.state!=="done") return;
	const index=run.products.findIndex(p=>p.check===r.checkpoint);
	if (index<0) return;
	const later=run.effects.slice(run.effects.indexOf(writer)+1);
	const checks=later.filter(e=>{
		if (e.kind!=="component" || e.grain!==to || checkReceipt(e)?.exit!==0) return false;
		const pair=pairedInput(run,e);
		const observer=e.observer;
		return pair ? (observer ? !!observer.after && later.some(w=>w.kind==="writer" && w.observer?.pair===observer.pair &&
			w.nativeId===e.issuer && w.observer.after===observer.after) : e.issuer===run.owner) && pair.checkpoint===r.checkpoint && pair.retainer===r.retainer &&
			later.some(old=>old.id===pair.failed && old.issuer===writer.nativeId) : e.issuer===writer.nativeId;
	});
	return run.products.slice(index+1).find(p=>p.ownership?.[to] && p.outputs[r.retainer] && p.ownership[r.retainer] &&
		checks.some(e=>{
			if (e.kind!=="component" || e.commit!==p.outputs[to]) return false;
			const pair=pairedInput(run,e);
			return (!pair || p.outputs[r.retainer]===pair.candidate && p.target===pair.target) && run.effects.indexOf(e)<run.effects.findIndex(c=>c.id===p.check);
		}));
}

/** Detect a pre-guard, already-issued replacement. Old products need not have a
 * frozen ownership map: the confirmed writer's finished record binds its grant to
 * the passing product. A single unambiguous observed grant can also be matched to
 * its checked candidate if the writer had not yet been marked finished.
 * @param {import("./model.js").Run} run */
function* displacements(run) {
	if (!run.products.length) return;
	/** @type {Map<string,import("./model.js").FileScope>} */
	const grants=new Map();
	/** @type {Map<string,import("./model.js").FileScope[]>} */
	const proposals=new Map();
	const ordinary=new Set();
	for (const e of run.effects) {
		if (e.kind==="writer" && e.grain && e.finished && mixed(e.finished.directory)) grants.set(e.grain,e.finished.directory);
		if (e.kind!=="scout" || e.state!=="observed") continue;
		for (const g of e.observation?.grains ?? []) if (typeof g!=="string") {
			if (mixed(g.directory)) proposals.set(g.id,[...proposals.get(g.id) ?? [],g.directory]);
			else ordinary.add(g.id);
		}
	}
	for (const p of run.products) if (p.ownership) for (const [id,scope] of Object.entries(p.ownership))
		if (scope.files.length && scope.directories.length===1) grants.set(id,{primary:scope.directories[0],files:scope.files});
	if (!grants.size && !proposals.size) return;
	for (const [id,scopes] of proposals) {
		if (ordinary.has(id) || grants.has(id) || run.nodes[id] && sameScope(run.nodes[id].grain.directory,scopes[0])) continue;
		const writers=run.effects.filter(e=>e.kind==="writer" && e.grain===id && e.nativeId);
		if (writers.length===1 && scopes.every(s=>sameScope(s,scopes[0])) && run.products.some(p=>p.outputs[id] &&
			run.effects.some(e=>e.kind==="component" && e.grain===id && e.issuer===writers[0].nativeId &&
				e.commit===p.outputs[id] && checkReceipt(e)?.exit===0))) grants.set(id,scopes[0]);
	}
	const nodes=Object.values(run.nodes);
	for (const [id,scope] of grants) {
		if (nodes.some(n=>sameScope(n.grain.directory,scope))) continue;
		if (run.effects.some(e=>{
			if (e.kind!=="writer" || e.restoration?.from!==id || !e.grain) return false;
			const p=restoredProduct(run,e), owner=p?.ownership?.[e.restoration.retainer], primary=p?.ownership?.[e.grain];
			return p && owner && primary?.directories.length===1 && primary.directories[0]===scope.primary && !primary.files.length &&
				scope.files.every(f=>owner.files.includes(f) || owner.directories.some(d=>contains(d,f))) &&
				!run.products.slice(run.products.indexOf(p)).some(product=>product.outputs[id]);
		})) continue;
		const replacements=nodes.filter(n=>!n.restoration && !outside(n.grain.directory,roots(scope)));
		if (replacements.length) yield {id,scope,replacements};
	}
}

/** @param {import("./model.js").Run} run @param {string} from */
export const displacement=(run,from)=>[...displacements(run)].find(d=>d.id===from);

/** @param {import("./model.js").Run} run @param {Record<string,string>} [outputs] @param {string} [target] */
export function partitionConflict(run,outputs,target) {
	for (const {id,scope,replacements} of displacements(run)) {
		const receiver=Object.values(run.nodes).find(n=>n.restoration?.from===id && n.grain.directory===scope.primary);
		const retainer=replacements.find(n=>n.grain.id===receiver?.restoration?.retainer);
		const check=receiver?.check && run.effects.find(e=>e.id===receiver.check);
		const pair=check && check.kind==="component" && pairedInput(run,check);
		if (pair && !matchesPair(run,pair,target))
			return `The approved pair for ${id} no longer matches the target, checkpoint, goal or retaining component.`;
		if (receiver && retainer && replacements.length===1 && [receiver,retainer].every(n=>n.candidate &&
			["published","qualified"].includes(n.state) && (!outputs || outputs[n.grain.id]===n.candidate))) continue;
		return receiver ? `Ownership restoration of ${scope.primary} requires fresh included evidence from ${receiver.grain.id} and its paired owner ${receiver.restoration?.retainer}.` :
			`Checked mixed grant ${id} (${scopeLabel(scope)}) lost its owner to ${replacements.map(n=>`${n.grain.id} (${scopeLabel(n.grain.directory)})`).join(", ")}. Keep the issued work and receipts; product integration requires an explicit ownership resolution.`;
	}
}
