import { randomUUID } from "node:crypto";
import { decide, observeReply, presentDialog } from "./dialog.mjs";
import { currentReview } from "./graph.mjs";
import { admitted, expired } from "./native.mjs";
import { commitAt } from "./product.mjs";
import { presentation, questions, reviews } from "./reviews.mjs";
import { fail } from "./values.mjs";

/** @typedef {{review:string,presentation:string}} Recovery */
const stale = () => fail("stale_question", "This charter question or presentation is not current; read foundry_status.");

/** Claim the charter decision before opening its dialog. Native writer requests have
 * their own identity and never answer (or suppress) a scout's question.
 * @param {string} cwd @param {()=>Pick<ReturnType<typeof import("./database.mjs").openDatabase>, "planAndSwap">|undefined} liveStore
 * @param {string} id @param {string} owner @param {Pick<Parameters<typeof import("./runtime.mjs").createRuntime>[1], "ask"|"permissionBlocker"|"log">} host
 * @param {()=>Promise<boolean>} executable @param {()=>Promise<void>} wake
 * @param {(write:()=>unknown)=>Promise<unknown>} recordReply @param {Recovery} [recover] */
export async function presentQuestions(cwd, liveStore, id, owner, host, executable, wake, recordReply, recover) {
	do {
		const block = await host.permissionBlocker();
		const ask=host.ask;
		if (!ask || block || !await executable()) {
			if (recover) fail("question_unavailable", block?.message ?? "The owner session cannot present a question now.");
			return host.ask ? "issuer-permission" : undefined;
		}
		const store = liveStore();
		if (!store) return;
		let reviewId = "";
		/** @type {ReturnType<typeof decide>|undefined} */ let claim;
		const next = recover && randomUUID();
		const claimed = store.planAndSwap(id, run => {
			reviewId = "";
			claim=undefined;
			if (recover) {
				if (run.owner !== owner) fail("foreign_run", "Only the run owner can recover its question");
				admitted(run);
			} else if (!run.active || expired(run) || run.owner !== owner) return;
			const target = recover && commitAt(cwd, run.policy.target);
			const q = questions(run).find(r => (recover
				? r.id === recover.review && r.observation?.ownerInput && presentation(r) === recover.presentation
				: !r.decision) && currentReview(cwd, run, r, target));
			if (recover && !q) stale();
			if (!q?.observation) return;
			claim=decide(q,{ status: "presenting", ...(next ? { presentation: next } : {}) },!!recover,recover?.presentation);
			reviewId = q.id;
			if (target) return () => commitAt(cwd, run.policy.target) === target;
		});
		const q = reviews(claimed).find(r => r.id === reviewId);
		if (!q?.observation || !claim) return;
		const label = `${q.squad} at ${q.base}: ${q.observation.reason}\nEvidence: ${q.observation.evidence.join(", ")}`;
		/** @type {import("./dialog.mjs").Reply} */ let decision;
		// Normalize synchronous host failures without misclassifying an invalid effect claim as a delivery failure.
		const asking=presentDialog(claim,async()=>ask(`Foundry ${id}: ${label}\nClarify within the committed brief for one fresh review. This cannot change the contract or approve permissions.`));
		try {
			const answer = await asking;
			decision = answer?.trim() ? { status: "answered", answer } : { status: "dismissed" };
		} catch {
			decision = { status: "unavailable", presentation: next ?? reviewId,
				reason: "Question delivery is unconfirmed. Only an explicit owner request can reopen it." };
			host.log?.(`Foundry ${id}: ${decision.reason}`);
		}
		// Record a reply even in plan mode or through a pause. Only dispatch needs permission to run.
		let ready = false;
		const recorded=await recordReply(()=>liveStore()?.planAndSwap(id, run => {
			ready = false;
			const q = reviews(run).find(r => r.id === reviewId);
			const wasOpen=q && (!recover || questions(run).includes(q));
			if (!q || !observeReply(q,next??reviewId,decision).edge) {
				if (recover) stale();
				return;
			}
			const target = recover && commitAt(cwd, run.policy.target);
			const current = (recover || decision.status === "answered") && !expired(run) && currentReview(cwd, run, q, target);
			if (recover && (!current || !wasOpen)) stale();
			if (decision.status === "answered" && current) {
				if (run.goal) delete run.goal.stall;
				ready = run.active;
			}
			if (target) return () => commitAt(cwd, run.policy.target) === target;
		}));
		if(!recorded)return;
		if (ready) await wake();
	} while (!recover);
}
