import { checkReceipt } from "./evidence.mjs";
import { outside } from "./product.mjs";
import { digest } from "./values.mjs";

/** @typedef {import("./model.js").Run} Run */
/** @typedef {import("./model.js").Adoption} Adoption */
/** @typedef {Omit<Adoption,"id"|"basis"|"decision"|"previous">} Subject */

/** Approval identity is the authorized inputs, not the wording or formatting of their presentation.
 * @param {Subject} s */
export const offerId=s=>digest([s.revision,s.checkpoint,s.goal,s.assembly??null,s.manifest??s.message]);

/** @param {Run} run */
export function currentOffer(run){
	const a=run.adoptions?.at(-1);
	if(a && a.id===run.targetProposal && a.checkpoint===run.products.at(-1)?.check && a.goal===run.goal?.check &&
		a.revision!==run.policy.contractTarget)return a;
}

/** @param {Run} run */
export function pendingAdoption(run) {
	const a=currentOffer(run);
	return run.active && a?.assembly && !a.decision ? a : undefined;
}

/** @param {Run} run @param {Adoption} selected */
export function rememberOffer(run,selected){
	const offers=run.adoptions??=[], existing=offers.find(a=>a.id===selected.id);
	run.targetProposal=selected.id;
	if(!existing){offers.push(selected);return selected;}
	existing.basis=selected.basis;
	if(!existing.decision)existing.message=selected.message;
	if(existing!==offers.at(-1)){offers.splice(offers.indexOf(existing),1);offers.push(existing);}
	return existing;
}

/** A stored question is not an approval. An answered question must link to the exact adopted assembly and evaluator change.
 * @param {Run} run @param {Map<string,import("./model.js").Product>} products @param {Map<string,import("./model.js").Effect>} effects */
export function validOffers(run,products,effects){
	const offers=run.adoptions??[];
	if(run.targetProposal && run.targetProposal!==offers.at(-1)?.id || new Set(offers.map(a=>a.id)).size!==offers.length)return false;
	return offers.every(a=>{
		const p=products.get(a.checkpoint),g=effects.get(a.goal),m=a.manifest,d=a.decision;
		if(a.id!==offerId(a) || !!m!==!!a.assembly || !p || g?.kind!=="goal" || g.commit!==p.commit ||
			![1,2].includes(checkReceipt(g)?.exit??-1) || a.revision===p.target || !a.assembly && (d || a.previous))return false;
		if(m && (!m.files.length || m.files.includes(run.policy.source) || m.goalFrom!==(g.evaluatorRevision??run.policy.base) ||
			new Set(m.files).size!==m.files.length || m.resolutions?.some(r=>!outside(r.file,[".foundry",...run.policy.files]))))return false;
		if(a.previous?.some(prior=>prior.status!=="dismissed" && prior.status!=="unavailable") ||
			d?.status==="presenting" && (!d.presentation || a.id!==run.targetProposal))return false;
		if(d?.status!=="answered")return true;
		const pin=run.productRepins?.find(pin=>pin.targetFrom && pin.revision===a.revision), product=pin &&
			(products.get(pin.recheck)??(run.join?.check===pin.recheck ? run.join : undefined));
		return !!pin && !!m && pin.targetFrom===m.from && pin.from===m.productFrom && pin.checkpoint===p.check && pin.goal===g.id &&
			pin.acceptance===d.answer && !!product && product.commit===a.assembly && digest(product.outputs)===digest(m.outputs) &&
			digest(pin.files)===digest(m.files) && digest([...(pin.resolutions??[])].sort((a,b)=>a.file<b.file?-1:1))===digest(m.resolutions??[]);
	});
}
