import { currentRollout, foregroundLine, foregroundVariable, rolloutChecks, rolloutOffer, within } from "./campaign.mjs";
import { checkReceipt } from "./evidence.mjs";
import { admitted, reserveCheck } from "./native.mjs";
import { commitAt, git, regularFiles } from "./product.mjs";
import { digest, fail, fields, integer, name, record, relative } from "./values.mjs";

/** @param {string} cwd @param {import("./model.js").Run} run @param {string} actor @param {Record<string,unknown>} args
 * @param {(c:import("./model.js").NativeCall)=>void} verify */
export function retryForeground(cwd,run,actor,args,verify){
	if(actor!==run.owner)fail("foreign_run","Only the owner can enable a foreground check");
	fields(args,["run","assembly","check","declarations"]);
	admitted(run);
	const old=run.effects.find(e=>e.id===args.check),a=old?.kind==="component" && rolloutOffer(run,old);
	if(!a || !a.rollout || !a.assembly || a.foreground || a.assembly!==args.assembly || !old.grain || !old.check ||
		!currentRollout(run,old) || commitAt(cwd,run.policy.target)!==a.revision || run.effects.some(e=>e.permissionHold) || run.inspections?.some(i=>i.permissionHold))
		fail("stale_assignment","Need the exact current adopted rollout and its original withheld component; no other grant is changed");
	const batch=rolloutChecks(run,a),pos=batch.indexOf(old),variable=foregroundVariable(old);
	if(!variable || pos<0 || batch.some((c,i)=>!currentRollout(run,c) || (i<pos ? !c.runnerClaim || checkReceipt(c)?.exit!==0 :
		i>pos && (c.state!=="ready" || c.callId || c.runnerStarted || c.receipt))))
		fail("not_recoverable","Need a signed foreground opt-in diagnostic (exit 2) followed only by unissued rollout checks");
	for(const c of batch.slice(0,pos+1))verify(c);
	/** @type {NonNullable<import("./model.js").Adoption["foreground"]>["grains"]} */ const grains={};
	if(!Array.isArray(args.declarations))fail("invalid_field","Name the single-purpose foreground components and their pinned declaration lines");
	for(const value of args.declarations){
		const d=record(value);fields(d,["grain","file","line"]);
		const id=name(d.grain,"foreground grain"),file=relative(d.file),line=integer(d.line,1,"foreground declaration line");
		const included=a.rollout.included[id];
		if(!included || grains[id] || !within(included.scope,file))fail("patch_scope",`Not a unique owned declaration for ${id}`);
		const [{oid:blob}]=regularFiles(cwd,a.assembly,[file]),declaration=git(cwd,["cat-file","blob",blob]).toString("utf8").split(/\r?\n/)[line-1];
		if(!declaration || !foregroundLine(declaration))
			fail("invalid_declaration",`No explicit foreground preflight at ${file}:${line}`);
		grains[id]={file,number:line,line:declaration,blob};
	}
	if(!grains[old.grain])fail("invalid_declaration","The withheld grain needs its own reviewed foreground declaration");
	const retry=reserveCheck(run,actor,cwd,a.assembly,old.check,old.grain);
	const c=run.effects.at(-1);
	if(c?.kind!=="component")throw Error("Missing foreground retry reservation");
	c.rollout=a.id;
	a.foreground={check:old.id,retry,variable,grains};
	const stamp=digest(a.foreground);
	for(const e of [c,...batch.slice(pos+1)])if(e.grain && grains[e.grain])e.lane=stamp;
	return ()=>commitAt(cwd,run.policy.target)===a.revision;
}
