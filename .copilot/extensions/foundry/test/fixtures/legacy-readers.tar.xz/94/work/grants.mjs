import { executor } from "./adapter.mjs";
import { prepareBaselines } from "./baseline.mjs";
import { prepareCheckpoint } from "./checkpoint.mjs";
import { prepareCorrection } from "./correction.mjs";
import { prepareDelivery } from "./delivery.mjs";
import { transition } from "./machine.mjs";
import { prepareObserver } from "./observer.mjs";
import { prepareProduction } from "./production.mjs";
import { inputEvidence, prepareInput } from "./resupply.mjs";
import { prepareRestoration } from "./restoration.mjs";
import { prepareReuse } from "./reuse.mjs";
import { strategy } from "./strategy.mjs";
import { digest, fields, FoundryError } from "./values.mjs";

/** @typedef {import("./model.js").Run} Run */
/** @typedef {(e:import("./model.js").NativeCall)=>void} Verify */
/** @typedef {{prompt:string,apply:(r:Run)=>()=>boolean,consent?:"native"|"satisfied"|"policy",wake?:"none"|"recover"|"ready"}} Grant */
/** @typedef {(cwd:string,run:Run,actor:string,args:Record<string,unknown>,verify:Verify)=>Grant} Prepare */
/** @typedef {{operation:string,attempt:string,args:{grain:string;blob:string}}} Proposal */
/** @param {boolean} inspect @returns {Prepare} */
const baseline=inspect=>(cwd,run,actor,args,verify)=>{
	fields(args,["run","grains"]);
	return prepareBaselines(cwd,run,actor,args.grains,inspect,verify);
};
/** @type {Readonly<Record<string,Prepare>>} */
const operations=Object.freeze({inspectBaseline:baseline(true),repairBaseline:baseline(false),input:prepareInput,correct:prepareCorrection,
	reuse:prepareReuse,restore:prepareRestoration,diagnose:prepareObserver,checkpoint:prepareCheckpoint,remediate:prepareProduction,deliver:prepareDelivery});
/** @param {string} op */
export const grantFor=op=>Object.hasOwn(operations,op)?operations[op]:undefined;

/** Bind trusted edition rules once. The result of a match contains only a subject and operation name.
 * @param {import("./machine.mjs").Machine} [rules] */
export function recoveryRules(rules=strategy) {
	const propose=executor(rules,Object.fromEntries(Object.keys(operations).map(operation=>[operation,
		(/** @type {Omit<Proposal,"operation">} */ subject)=>({operation,...subject})])));
	/** @param {Run} run */
	function select(run) {
		/** @type {Map<string,Proposal>} */ const found=new Map();
		for(const {signal,facts,...subject} of inputEvidence(run)){
			const choice=transition(rules,{value:rules.initial,context:null},{type:signal},facts,false);
			const [proposal]=propose(choice,subject);
			if(proposal)found.set(digest(proposal),proposal);
		}
		return found;
	}
	return {select,
		/** @param {string} cwd @param {Run} run @param {string} actor @param {Map<string,Proposal>} sampled @param {Verify} verify */
		apply(cwd,run,actor,sampled,verify){
			/** @type {(()=>boolean)[]} */ const guards=[];
			for(const [key,p] of select(run)){
				if(!sampled.has(key) || run.nodes[p.args.grain]?.token!==p.attempt)continue;
				let grant;
				try{
					grant=operations[p.operation](cwd,run,actor,{run:run.id,...p.args},verify);
				}catch(error){
					if(!(error instanceof FoundryError))throw error;
					const need=run.nodes[p.args.grain]?.stop?.input;
					if(need)need.hold=error.message;
					continue;
				}
				if(grant.consent==="satisfied")guards.push(grant.apply(run));
			}
			return guards.length?()=>guards.every(guard=>guard()):undefined;
		}};
}
